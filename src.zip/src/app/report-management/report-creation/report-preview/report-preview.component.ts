/// C:\Users\mykiranahub1\Desktop\Valora\valorademo\valorademo\src\app\report-management\report-creation\report-preview\report-preview.component.ts


import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-report-preview',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report-preview.component.html',
  styleUrl: './report-preview.component.css'
})
export class ReportPreviewComponent implements OnInit {

  reportPath = '';
  reportId = '';
  downloadUrl = '';
  googleDocsUrl = '';
  isLocalhostServer = false;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.reportPath = params['path'] || '';
      this.reportId   = params['reportId'] || '';

      if (this.reportPath) {
        // ── Build full download URL ──
        this.downloadUrl = `${environment.apiBaseUrl}${this.reportPath}`;

        // ── Check if server is localhost ──
        this.isLocalhostServer = this.downloadUrl.includes('localhost') ||
                                  this.downloadUrl.includes('192.168.');

        // ── Google Docs Viewer URL (only works for public URLs) ──
        if (!this.isLocalhostServer) {
          this.googleDocsUrl = `https://docs.google.com/viewer?url=${encodeURIComponent(this.downloadUrl)}&embedded=true`;
        }
      }
    });
  }

  downloadReport() {
    const link = document.createElement('a');
    link.href = this.downloadUrl;
    link.download = `Report_${this.reportId}.docx`;
    link.click();
  }

  openInWord() {
    window.open(this.downloadUrl, '_blank');
  }
}