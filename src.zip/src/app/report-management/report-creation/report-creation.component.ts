import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { concatMap } from 'rxjs/operators';
import { UploadHeaderComponent } from './upload-header/upload-header.component';
import { ReportFormComponent } from './report-form/report-form.component';
import { VisitDetailsComponent } from './visit-details/visit-details.component';
import { PhotoOrganizerComponent } from './photo-organizer/photo-organizer.component';
import { MarcketPhotoComponent } from './marcket-photo/marcket-photo.component';
import { OtherdetailsComponent } from '../otherdetails/otherdetails.component';
import { RepmanageserviceService } from '../repmanageservice.service';
import { PhotoOrganizerService } from './service/photo-organizer.service';
import { MediaUploadComponent } from './media-upload/media-upload.component';

@Component({
  selector: 'app-report-creation',
  standalone: true,
  imports: [
    CommonModule,
    UploadHeaderComponent,
    ReportFormComponent,
    OtherdetailsComponent,
    VisitDetailsComponent,
    PhotoOrganizerComponent,
    MarcketPhotoComponent,
    MediaUploadComponent
  ],
  templateUrl: './report-creation.component.html',
  styleUrl: './report-creation.component.css'
})
export class ReportCreationComponent implements OnInit, AfterViewInit {

  visitMessage = '';
  uploadedFiles: any = {};
  propertyPhotos: any[] = [];
  selectedPhotos: any[] = [];
  marketPhotos: File[] = [];

  @ViewChild(ReportFormComponent) reportForm!: ReportFormComponent;
  @ViewChild(VisitDetailsComponent) visitDetails!: VisitDetailsComponent;
  @ViewChild(OtherdetailsComponent) valuationDetails!: OtherdetailsComponent;
  @ViewChild(MediaUploadComponent) mapAttachments!: MediaUploadComponent;

  reportId = '';
  draftId = '';
  creatingReport = false;

  constructor(
    private route: ActivatedRoute,
    private reportService: RepmanageserviceService,
    private photoService: PhotoOrganizerService,
    private cdr: ChangeDetectorRef
  ) {
    console.log("ReportCreation service:", this.photoService);
  }

  ngOnInit() {
    this.cdr.detectChanges();

    this.route.queryParams.subscribe(params => {
      this.reportId = params['reportId'] || '';
      this.draftId = params['draftId'] || '';
    });

    this.photoService.selectedPhotos$.subscribe(photos => {
      console.log("📸 Selected photos received in ReportCreation:", photos);
      this.selectedPhotos = photos;
    });
  }

  ngAfterViewInit() {
    console.log("ReportForm:", this.reportForm);
    console.log("VisitDetails:", this.visitDetails);
  }

  /* ════════════════════════
     VALIDATION
  ════════════════════════ */
  validateBeforeCreate(): string[] {
    const errors: string[] = [];

    if (!this.reportForm || !this.visitDetails) {
      errors.push("Form not loaded yet");
      return errors;
    }

    const form = this.reportForm.formData;
    const visit = this.visitDetails.visitDetails;

    if (!form.ownerName?.trim()) errors.push("Owner Name is required");
    if (!form.propertyLocation?.trim()) errors.push("Property Location is required");
    if (!form.village?.trim()) errors.push("Village is required");
    if (!form.district?.trim()) errors.push("District is required");
    if (!form.pincode?.trim()) errors.push("Pincode is required");
    if (!visit.buildingName?.trim()) errors.push("Building Name is required");
    if (!visit.flatNo?.trim()) errors.push("Flat Number is required");
    if (!this.selectedPhotos?.length) errors.push("At least one property photo is required");

    return errors;
  }

  /* ════════════════════════
     EVENT HANDLERS
  ════════════════════════ */
  handleVisitMessage(message: string) {
    this.visitMessage = message;
  }

  handleFileUpload(fileData: any) {
    if (fileData.removed) {
      delete this.uploadedFiles[fileData.type];
    } else {
      this.uploadedFiles[fileData.type] = fileData;
    }
  }

  handleMarketPhotos(files: File[]) {
    console.log("🏪 Market photos received in ReportCreation:", files);
    this.marketPhotos = files;
  }

  handleExtraction(data: any) {
    console.log("📡 STEP 2: Parent handleExtraction received:", data);
    if (this.mapAttachments) {
      console.log("✅ STEP 2.1: mapAttachments component found. Pushing data now...");
      this.mapAttachments.setAddressData(data);
    } else {
      console.error("❌ STEP 2.2: mapAttachments (@ViewChild) is UNDEFINED. Check HTML selector.");
    }
  }

  /* ════════════════════════
     CREATE REPORT
  ════════════════════════ */
  createReport() {
    const errors = this.validateBeforeCreate();
    if (errors.length > 0) {
      alert(errors.join('\n'));
      return;
    }
    // ── Check if map is still being generated ──
    if (this.mapAttachments?.isProcessing) {
      alert('Location map is still being generated.\nPlease wait for it to complete and try again.');
      return;
    }
    this.creatingReport = true;
    // ── Trigger valuation table save before building payload ──
    if (this.valuationDetails?.valuationTable) {
      this.valuationDetails.valuationTable.saveTable();
    }
    // 1. Capture snapshots from child components
    const basicData = this.reportForm.formData;
    const visitDataRaw = this.visitDetails.visitDetails;
    const valuationData = this.valuationDetails.formData;
    // 2. Visit Payload
    const visitPayload = {
      reportId: this.reportId,
      draftId: this.draftId,
      north: visitDataRaw.northBoundary,
      south: visitDataRaw.southBoundary,
      east: visitDataRaw.eastBoundary,
      west: visitDataRaw.westBoundary,
      occupied: visitDataRaw.occupied,
      flatBHK: visitDataRaw.flatType,
      floors: visitDataRaw.totalFloor,
      perfloor: visitDataRaw.perFloor,
      totalflats: visitDataRaw.totalFlat,
      lifts: visitDataRaw.lift,
      parking: visitDataRaw.parking,
      perfloorflat: visitDataRaw.perFloor,
      flatNo: visitDataRaw.flatNo,
      landmark: visitDataRaw.landmark
    };
    // 3. Valuation Payload
    const valuationPayload = {
      reportId: this.reportId,
      draftId: this.draftId,
      ...valuationData,
      // ── Site Details ──
      extentofsite: this.valuationDetails.siteDetails?.formData?.extentSite || '',
      extentofsiteconsiderforvaluation: this.valuationDetails.siteDetails?.formData?.extentValuation || '',
      plinthareaofflat: this.valuationDetails.siteDetails?.formData?.plinthArea || '',
      carpetareaofflat: this.valuationDetails.siteDetails?.formData?.carpetArea || '',
      // ── Valuation Table ──
      valuationTables: this.valuationDetails.valuationTableData || null,
      guidelineCalculatedValue: this.valuationDetails.cleanCurrency(valuationData.guidelineCalculatedValue),
      fairMarketValue: this.valuationDetails.cleanCurrency(valuationData.fairMarketValue),
      realizableValue: this.valuationDetails.cleanCurrency(valuationData.realizableValue),
      distressValue: this.valuationDetails.cleanCurrency(valuationData.distressValue),
      insurableValue: this.valuationDetails.cleanCurrency(valuationData.insurableValue),
      rentalValue: this.valuationDetails.cleanCurrency(valuationData.rentalValue),
      guidelineBookValue: this.valuationDetails.cleanCurrency(valuationData.guidelineBookValue)
    };
    // ── LOG ──
    console.group('📋 [ReportCreation] Valuation Payload Check');
    console.log('valuationTableData:', this.valuationDetails.valuationTableData);
    console.log('extentofsite:', valuationPayload.extentofsite);
    console.log('extentofsiteconsiderforvaluation:', valuationPayload.extentofsiteconsiderforvaluation);
    console.log('plinthareaofflat:', valuationPayload.plinthareaofflat);
    console.log('carpetareaofflat:', valuationPayload.carpetareaofflat);
    console.log('valuationTables:', JSON.stringify(valuationPayload.valuationTables, null, 2));
    console.groupEnd();
    // 4. Chain API calls
    this.reportService.saveBasicDetails({ reportId: this.reportId, draftId: this.draftId, ...basicData })
      .pipe(
        concatMap(() => {
          console.log("✅ Basic Details Saved");
          return this.reportService.saveVisitDetails(visitPayload);
        }),
        concatMap(() => {
          console.log("✅ Visit Details Saved");
          return this.reportService.saveValuationDetails(valuationPayload);
        }),
        concatMap(() => {
          console.log("📦 Constructing Final FormData...");

          const finalForm = new FormData();
          finalForm.append("reportId", this.reportId);
          finalForm.append("draftId", this.draftId);

          // Attachments
          if (this.mapAttachments) {
            if (this.mapAttachments.reckonerFile) {
              console.log("📄 Appending Ready Reckoner Photo");
              finalForm.append("reckonerPhoto", this.mapAttachments.reckonerFile);
            }
            if (this.mapAttachments.locationMapFile) {
              console.log("📍 Appending Location Map Photo");
              finalForm.append("locationMap", this.mapAttachments.locationMapFile);
            }
          }
          // Visit Photos
          console.log(`📸 Appending ${this.selectedPhotos.length} Visit Photos`);
          this.selectedPhotos.forEach((p) => {
            finalForm.append("visitImages", p.file);
          });
          //  Market Photos
          console.log(`🏪 Appending ${this.marketPhotos.length} Market Photos`);
          if (this.marketPhotos?.length > 0) {
            this.marketPhotos.forEach((file, index) => {
              console.log(`   > Adding Market Photo ${index + 1}:`, file.name);
              finalForm.append("marketPhotos", file);
            });
          } else {
            console.warn("⚠️ No Market Photos found");
          }

          return this.reportService.createReport(finalForm);
        })
      )
      .subscribe({

    next: (res: any) => {
  if (res.success && res.reportPath) {
    console.log("🎉 Report created successfully at:", res.reportPath);
    // ── Open report preview in new tab ──
    const previewUrl = `/report-preview?path=${encodeURIComponent(res.reportPath)}&reportId=${this.reportId}`;
    window.open(previewUrl, '_blank');
  } else {
    alert("Report generation failed.");
  }
  this.creatingReport = false;
},

        error: (err) => {
          console.error("❌ Process failed:", err);
          alert("An error occurred during saving.");
          this.creatingReport = false;
        }
      });
  }

  /* ════════════════════════
     CLEANUP
  ════════════════════════ */
  ngOnDestroy() {
    console.log("🧹 Cleaning up screen data on navigation...");
    if (this.photoService) {
      this.photoService.resetService();
    }
    this.visitMessage = '';
    this.selectedPhotos = [];
    this.uploadedFiles = {};
  }
}