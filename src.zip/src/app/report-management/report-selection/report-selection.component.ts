import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RepmanageserviceService } from '../repmanageservice.service';

@Component({
  selector: 'app-report-selection',
  standalone: true,
  templateUrl: './report-selection.component.html',
  styleUrl: './report-selection.component.css'
})
export class ReportSelectionComponent {

  constructor(
    private router: Router,
    private reportService: RepmanageserviceService
  ) {}

  // Flat Report
 selectFlatReport() {

  const draftId = "draft1";

  this.reportService.selectDraft(draftId).subscribe((res:any) => {

    this.router.navigate(['/report-creation'], {
      queryParams: {
        reportId: res.reportId,
        draftId: draftId
      }
    });

  });

}

  // Land Report (not implemented)
  selectLandReport() {
    alert("Land report coming later");
  }

}