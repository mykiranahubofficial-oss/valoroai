//// C:\Users\mykiranahub1\Desktop\Valora\valorademo\src\app\report-management\repmanageservice.service.ts

//// C:\Users\mykiranahub1\Desktop\Valora\valorademo\src\app\report-management\repmanageservice.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { switchMap, catchError } from 'rxjs/operators';
import { fromFetch } from 'rxjs/fetch';

import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class RepmanageserviceService {

  private baseUrl = `${environment.apiBaseUrl}/report`;
  private autoDocuUrl = `${environment.apiBaseUrl}/autodocu`;

  constructor(private http: HttpClient) {}

  /* ===============================
     Select Draft
  =============================== */

  selectDraft(draftId: string): Observable<any> {
    const url = `${this.baseUrl}/selectdraft?draftId=${draftId}`;
    console.log("Calling API:", url);
    return this.http.get(url);
  }

  /* ===============================
     Save Basic Details
  =============================== */

  saveBasicDetails(data: any): Observable<any> {
    const url = `${this.baseUrl}/basic-details/save`;
    console.log("Saving Basic Details:", data);
    return this.http.post(url, data);
  }

  /* ===============================
     Save Visit Details
  =============================== */

  saveVisitDetails(data: any): Observable<any> {
    const url = `${this.baseUrl}/visit-details/save`;
    console.log("Saving Visit Details:", data);
    return this.http.post(url, data);
  }

  /* ===============================
     OCR TEXT EXTRACTION
     Supports AbortSignal for cancellation via fromFetch
  =============================== */

  extractText(files: File | File[], reportId: string, signal?: AbortSignal): Observable<any> {

    const url = `${this.autoDocuUrl}/extract-text`;
    const formData = new FormData();
    const fileArray = Array.isArray(files) ? files : [files];

    fileArray.forEach(file => formData.append("files", file));
    formData.append("reportId", reportId);

    console.log("Calling OCR API:", url);
    console.log("ReportId:", reportId);
    console.log("File count:", fileArray.length);

    // ── Use fromFetch to support AbortSignal for cancellation ──
    return fromFetch(url, {
      method: 'POST',
      body: formData,
      signal: signal
    }).pipe(
      switchMap(response => {
        if (!response.ok) {
          throw new Error(`HTTP error: ${response.status}`);
        }
        return response.json();
      }),
      catchError(err => {
        if (err.name === 'AbortError') {
          console.log('🛑 Extraction request aborted by user');
          return of({ aborted: true });
        }
        console.error('🚨 extractText error:', err);
        throw err;
      })
    );
  }

  /* ===============================
     CREATE FINAL REPORT (WORD FILE)
  =============================== */

  createReport(formData: FormData): Observable<any> {

    const url = `${this.baseUrl}/create-report`;

    console.log("🚀 [ReportService] Sending report creation request");
    console.log("🌐 URL:", url);

    console.log("📦 [ReportService] FormData Payload:");
    formData.forEach((value, key) => {
      if (value instanceof File) {
        console.log(`   ${key}: [FILE] ${value.name} (${value.size} bytes)`);
      } else {
        console.log(`   ${key}:`, value);
      }
    });

    console.log("────────────────────────────");

    return this.http.post(url, formData);
  }

  /* ===============================
     SAVE VALUE LINKS IMAGES
  =============================== */

  saveValueLinks(files: File[], reportId: string): Observable<any> {
    const url = `${this.baseUrl}/value-links`;
    const formData = new FormData();
    formData.append("reportId", reportId);
    files.forEach(file => { formData.append("valueLinks", file); });

    console.log("🏪 Uploading value link images");
    formData.forEach((value, key) => {
      if (value instanceof File) {
        console.log(`📷 ${key}:`, value.name);
      } else {
        console.log(`📝 ${key}:`, value);
      }
    });

    return this.http.post(url, formData);
  }

  /* ===============================
     SAVE VALUATION DETAILS
  =============================== */

  saveValuationDetails(data: any): Observable<any> {
    const url = `${this.baseUrl}/saveValuationDetails/save`;
    console.log("Saving Valuation Details:", data);
    return this.http.post(url, data);
  }

  /* ===============================
     SEARCH COMPARABLE PROPERTY VALUES
  =============================== */

  searchValue(
    buildingName: string,
    address: string,
    areaSqft: number | string,
    areaType: string,
    bhk?: string
  ): Observable<any> {
    let params = `buildingName=${encodeURIComponent(buildingName)}&address=${encodeURIComponent(address)}&areaSqft=${areaSqft}&areaType=${encodeURIComponent(areaType)}`;
    if (bhk) params += `&bhk=${encodeURIComponent(bhk)}`;
    const url = `${this.autoDocuUrl}/searchValue?${params}`;
    console.log("🔍 Calling Search Value API:", url);
    return this.http.get(url);
  }

  /* ===============================
     SATELLITE MAP AUTOMATION
  =============================== */

  triggerMapAutomation(data: {
    reportId: string;
    buildingName?: string;
    village?: string;
    city?: string;
    district?: string
  }): Observable<any> {
    const url = `${environment.apiBaseUrl}/maps/satellite`;
    console.log("🗺️ Triggering Map Automation via API:", url);
    return this.http.post(url, data);
  }

}