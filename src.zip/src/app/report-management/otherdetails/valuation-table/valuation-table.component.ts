import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AmountInWordsPipe } from '../../../shared/pipes/amount-in-words.pipe';

export interface ValuationRow {
  srNo: number;
  description: string;
  qty: string;
  ratePerUnit: string;
  estimatedValue: string;
  isFixed: boolean;
}

export interface ValuationTablePayload {
  reportId: string;
  valuationRows: ValuationRow[];
  totalValue: string;
  sayValue: string;
  amountInWords: string;
}

@Component({
  selector: 'app-valuation-table',
  standalone: true,
  imports: [CommonModule, FormsModule, AmountInWordsPipe],
  templateUrl: './valuation-table.component.html',
  styleUrl: './valuation-table.component.css'
})
export class ValuationTableComponent implements OnInit {

  @Input() reportId = '';

  // ── Emits every time any value changes ──
  @Output() dataChange = new EventEmitter<ValuationTablePayload>();

  rows: ValuationRow[] = [
    { srNo: 1, description: 'Present value of the Flat', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true },
    { srNo: 2, description: 'Present value of the Terrace Area', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true },
    { srNo: 3, description: 'Interior Decorations which carry a potential value, if any', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true },
    { srNo: 4, description: 'Others (Allotments/separate purchased car park or extended area etc.)', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true },
    { srNo: 5, description: 'Potential Value, If Any?', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true },
    { srNo: 6, description: 'Share Of Common Amenities, If Any?', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true },
    { srNo: 7, description: 'Value as on today (100% Work Completed)', qty: '', ratePerUnit: '', estimatedValue: '', isFixed: true }
  ];

  totalValue = '';
  sayValue = '';
  sayNumber = 0;
  amountInWords = '';

  ngOnInit() {
    console.log('🆕 [ValuationTable] INSTANCE CREATED — id:', Math.random(), '| reportId:', this.reportId);
  }

  /* ════════════════════════
     TRACK BY
  ════════════════════════ */
  trackByIndex(index: number, row: ValuationRow): number {
    return row.srNo;
  }

  /* ════════════════════════
     COMPUTED TOTAL
  ════════════════════════ */
  get computedTotal(): number {
    return this.rows.reduce((sum, row) => {
      const val = parseFloat((row.estimatedValue || '').replace(/,/g, ''));
      return sum + (isNaN(val) ? 0 : val);
    }, 0);
  }
  autoGrow(event: Event) {
  const el = event.target as HTMLTextAreaElement;
  el.style.height = 'auto';
  el.style.height = el.scrollHeight + 'px';
}

  /* ════════════════════════
     ON ANY FIELD CHANGE
  ════════════════════════ */
 onAnyChange() {

  const total = this.computedTotal;

  this.totalValue = total > 0 ? this.formatIndianCurrency(total) : '';

  const rounded = Math.round(total / 1000) * 1000;

  this.sayNumber = rounded;

  this.sayValue = rounded > 0 ? this.formatIndianCurrency(rounded) : '';

}
  /* ════════════════════════
     FORMAT HELPERS
  ════════════════════════ */
  formatIndianCurrency(value: number): string {
    return 'Rs. ' + value.toLocaleString('en-IN') + '/-';
  }

  formatInput(row: ValuationRow) {
    console.log('✏️ [ValuationTable] formatInput — row:', row.srNo, '| value:', row.estimatedValue);
    const raw = (row.estimatedValue || '').replace(/,/g, '').replace(/[^0-9.]/g, '');
    const num = parseFloat(raw);
    if (!isNaN(num)) {
      row.estimatedValue = num.toLocaleString('en-IN');
    }
    this.onAnyChange();
  }

  /* ════════════════════════
     BUILD PAYLOAD
  ════════════════════════ */
  private buildPayload(): ValuationTablePayload {
    return {
      reportId: this.reportId,
      valuationRows: this.rows.map(r => ({ ...r })), // snapshot copy
      totalValue: this.totalValue,
      sayValue: this.sayValue,
      amountInWords: this.amountInWords
    };
  }

  /* ════════════════════════
     GET PAYLOAD (called externally)
  ════════════════════════ */
  getPayload(): ValuationTablePayload {
    const payload = this.buildPayload();
    console.log('📦 [ValuationTable] getPayload():');
    payload.valuationRows.forEach(r => {
      console.log(`  Row ${r.srNo}: qty="${r.qty}" | rate="${r.ratePerUnit}" | estimated="${r.estimatedValue}"`);
    });
    return payload;
  }

  /* ════════════════════════
   SAVE TABLE DATA
════════════════════════ */
saveTable() {

  const payload = this.buildPayload();

  console.log("💾 [ValuationTable] SAVE BUTTON CLICKED");
  console.log("📤 [ValuationTable] Sending payload to parent:");
  console.log(JSON.stringify(payload, null, 2));

  this.dataChange.emit(payload);

}
}