import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { RegistrationService } from '../services/registration.service';
import { Agency } from '../model/agency.model';
import { TableBuilderComponent } from '../table-builder/table-builder.component';

@Component({
  selector: 'app-agencies',
  standalone: true,
  imports: [CommonModule, FormsModule, TableBuilderComponent],
  templateUrl: './agencies.component.html',
  styleUrl: './agencies.component.css'
})
export class AgenciesComponent implements OnInit {

  agencies: Agency[] = [];

  /* ── Edit Popup ── */
  showEditPopup = false;
  editForm: any = { userId: '', agencyName: '', ownerName: '' };

  /* ── Table Builder ── */
  showTableBuilder   = false;
  tableBuilderUserId = '';
  tableBuilderDraftId = '';

  constructor(private registrationService: RegistrationService) {}

  ngOnInit(): void {
    this.loadAgencies();
  }

  loadAgencies() {
    this.registrationService.getAgencies().subscribe({
      next: (res) => {
        if (res.success) this.agencies = res.data;
      },
      error: (err) => console.error('❌ Failed to fetch agencies', err)
    });
  }

  trackByUserId(_: number, agency: Agency) {
    return agency.userId;
  }

  /* ── Edit Agency ── */
  openEditPopup(agency: Agency) {
    this.editForm = {
      userId: agency.userId,
      agencyName: agency.agencyName,
      ownerName: agency.ownerName
    };
    this.showEditPopup = true;
  }

  closeEditPopup() {
    this.showEditPopup = false;
  }

  saveEdit() {
    this.registrationService.updateAgencyConfig({
      userId: this.editForm.userId,
      agencyName: this.editForm.agencyName,
      ownerName: this.editForm.ownerName
    }).subscribe({
      next: () => {
        this.showEditPopup = false;
        this.loadAgencies();
      },
      error: (err) => console.error('❌ Update failed', err)
    });
  }

  /* ── Table Builder ── */
  openTableBuilder(agency: Agency) {
    this.tableBuilderUserId  = agency.userId;
    this.tableBuilderDraftId = 'draft-' + agency.userId; // swap with real draftId if needed
    this.showTableBuilder    = true;
  }

  onTableBuilderClosed() {
    this.showTableBuilder = false;
  }
}