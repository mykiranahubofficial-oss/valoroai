import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RegistrationService } from '../services/registration.service';

import { Agency } from '../model/agency.model';

@Component({
  selector: 'app-register-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './register-form.component.html',
  styleUrl: './register-form.component.css'
})
export class RegisterFormComponent {

  agencyData: Agency = {
    agencyName: '',
    ownerName: '',
    address: '',
    mobileNumber: '',
    email: '',
    userId: '',
    drafts: []
  };

  userPass: string = '';

  constructor(private registrationService: RegistrationService) {}

  registerAgency() {

    const payload = {
      ...this.agencyData,
      userPass: this.userPass
    };

    console.log("📤 Submitting Agency Data");
    console.log(payload);

    this.registrationService.createAgency(payload).subscribe({

      next: (res) => {
        console.log("✅ Agency Created:", res);
        alert("Agency Registered Successfully");
      },

      error: (err) => {
        console.error("❌ Registration Failed:", err);
        alert("Failed to register agency");
      }

    });

  }

}