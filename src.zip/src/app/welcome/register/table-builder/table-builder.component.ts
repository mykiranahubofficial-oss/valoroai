import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { switchMap } from 'rxjs/operators';

import { RegistrationService } from '../services/registration.service';

export interface TableRow {
  cells: string[];
}

export interface ExtraColumn {
  name: string;
}

@Component({
  selector: 'app-table-builder',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './table-builder.component.html',
  styleUrl: './table-builder.component.css'
})
export class TableBuilderComponent implements OnChanges {

  @Input() visible = false;
  @Input() userId  = '';
  @Input() draftId = '';

  @Output() closed = new EventEmitter<void>();

  tableName = 'Table 1';

  fixedHeaders = [
    'Description',
    'Qty. (Sq.Ft)',
    'Rate per Unit (Rs)',
    'Estimated Value (Rs)'
  ];

  extraColumns: ExtraColumn[] = [];
  newColumnName = '';
  showColInput  = false;

  tableRows: TableRow[] = [];

  tableSaved  = false;
  isSaving    = false;
  saveError   = '';

  constructor(private registrationService: RegistrationService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['visible']?.currentValue === true) {
      this.reset();
    }
  }

  private reset() {
    this.tableName     = 'Table 1';
    this.extraColumns  = [];
    this.tableRows     = [this.emptyRow()];
    this.newColumnName = '';
    this.showColInput  = false;
    this.tableSaved    = false;
    this.isSaving      = false;
    this.saveError     = '';
  }

  get allHeaders(): string[] {
    return [...this.fixedHeaders, ...this.extraColumns.map(c => c.name)];
  }

  emptyRow(): TableRow {
    const total = this.fixedHeaders.length + this.extraColumns.length;
    return { cells: Array(total).fill('') };
  }

  trackRow(index: number)  { return index; }
  trackCell(index: number) { return index; }

  /* ── Row Operations ── */
  addRow() {
    this.tableRows.push(this.emptyRow());
  }

  removeRow(index: number) {
    if (this.tableRows.length > 1) {
      this.tableRows.splice(index, 1);
    }
  }

  /* ── Column Operations ── */
  confirmAddColumn() {
    const name = this.newColumnName.trim();
    if (!name) return;
    this.extraColumns.push({ name });
    this.tableRows.forEach(row => row.cells.push(''));
    this.newColumnName = '';
    this.showColInput  = false;
  }

  cancelAddColumn() {
    this.newColumnName = '';
    this.showColInput  = false;
  }

  /* ── Cell update ── */
  updateCell(row: TableRow, colIndex: number, value: string) {
    row.cells[colIndex] = value;
    if (colIndex === 1 || colIndex === 2) {
      const qty  = parseFloat(row.cells[1]) || 0;
      const rate = parseFloat(row.cells[2]) || 0;
      row.cells[3] = qty && rate ? (qty * rate).toFixed(2) : '';
    }
  }

  /* ── Save: Level 2 (create draft) → Level 3 (save table) ── */
  saveTable() {

    /* Guard: userId must be a real value */
    if (!this.userId || !this.draftId) {
      this.saveError = 'Missing userId or draftId.';
      return;
    }

    this.isSaving  = true;
    this.saveError = '';

    /* ── Level 2 payload: create/ensure draft exists ── */
    const draftPayload = {
      userId:    this.userId,
      draftId:   this.draftId,
      draftName: this.tableName
    };

    /* ── Level 3 payload: save table inside draft ── */
    const columnHeaders = this.allHeaders.map((title, i) => ({
      title,
      variable: `col_${i}`
    }));

    const rowHeaders = this.tableRows.map((_, i) => ({
      title: `Row ${i + 1}`,
      variable: `row_${i}`
    }));

    const cells = this.tableRows.map(row =>
      row.cells.map((value, j) => ({
        value,
        variable: `cell_${j}`
      }))
    );

    const tablePayload = {
      userId:        this.userId,
      draftId:       this.draftId,
      tableName:     this.tableName,
      columnHeaders,
      rowHeaders,
      cells
    };

    console.log('📝 Step 1 — Creating draft:', draftPayload);
    console.log('📊 Step 2 — Saving table:',  tablePayload);

    /* ── Call Level 2 first, then Level 3 ── */
    this.registrationService.updateAgencyConfig(draftPayload).pipe(
      switchMap(() => this.registrationService.updateAgencyConfig(tablePayload))
    ).subscribe({
      next: (res) => {
        console.log('✅ Table saved successfully', res);
        this.isSaving   = false;
        this.tableSaved = true;
        setTimeout(() => (this.tableSaved = false), 2500);
      },
      error: (err) => {
        console.error('❌ Save failed', err);
        this.isSaving  = false;
        this.saveError = err?.error?.message || 'Save failed. Check console.';
      }
    });
  }

  close() {
    this.closed.emit();
  }
}