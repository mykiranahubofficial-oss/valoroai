import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminGateComponent } from './admin-gate/admin-gate.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { AgenciesComponent } from './agencies/agencies.component';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, AdminGateComponent, RegisterFormComponent, AgenciesComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  unlocked = false;

  activeTab: 'register' | 'agencies' = 'register';

  handleAccess(event: boolean) {
    this.unlocked = event;
  }

  switchTab(tab:'register' | 'agencies'){
    this.activeTab = tab;
  }

}