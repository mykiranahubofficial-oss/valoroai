import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';

import { Agency, AgencyResponse } from '../model/agency.model';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  private apiUrl = `${environment.apiBaseUrl}/report`;

  constructor(private http: HttpClient) {}

  /* =========================================
     CREATE / UPDATE AGENCY
  ========================================= */

  createAgency(payload: Agency): Observable<AgencyResponse> {

    const url = `${this.apiUrl}/agency-draft/save`;

    console.log("🚀 Sending Agency Registration");
    console.log("📦 Payload:", payload);
    console.log("🌐 URL:", url);

    return this.http.post<AgencyResponse>(url, payload);
  }

/* =========================================
   FETCH ALL AGENCIES
========================================= */

getAgencies(): Observable<AgencyResponse> {

  const url = `${this.apiUrl}/agency-draft`;

  console.log("📡 Fetching all agencies");
  console.log("🌐 URL:", url);

  return this.http.get<AgencyResponse>(url);

}

 /* =========================================
     UPDATE AGENCY / DRAFT / TABLE
  ========================================= */

  updateAgencyConfig(payload: any): Observable<any> {

    const url = `${this.apiUrl}/agency-draft/update`;

    console.log("✏️ Updating agency config");
    console.log(payload);

    return this.http.patch(url, payload);

  }


}